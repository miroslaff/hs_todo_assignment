import {Context} from '../../core/context'
import { randomInt } from 'node:crypto'

class ToDoPage {
    ctx: Context
    constructor(ctx: Context) {
        this.ctx = ctx
    }

    readonly selectors = {   
        newTaskInput: "header .new-todo",
        taskList: ".main .todo-list",
        taskItems: ".main .todo-list > li",
        toggleButton: ".view input.toggle",
        removeButton: ".view button.destroy",
        taskText: ".view label",
        completedTasks: ".main li.completed",
        taskCountText: ".footer .todo-count strong",
        clearCompletedButton: ".footer button.clear-completed"
    }

    async createTask(description: string) {
        const addInput = this.ctx.page.locator(this.selectors.newTaskInput)
        await addInput.fill(description)
        await addInput.press("Enter")
    }

    async filterTasks(criteria: "All" | "Active" | "Completed" = "All") {
        const filterButton = this.ctx.page.getByText(criteria);
        await filterButton.click()
    }

    async getTaskCount(asNumber = true) {
        const countText = this.ctx.page.locator(this.selectors.taskCountText)
        const rawCount = await countText.textContent() ?? "0"
        return asNumber ? parseInt(rawCount) : rawCount
    }

    /** Returns the task item based on specified text or index. Picks random if nothing is specified */
    async getTask(indexOrText: number | string | undefined = undefined) {
        const count = await this.getTaskCount() as number;
        if (count < 1) {
            throw new Error("Task list is empty");
        }
        indexOrText = indexOrText ?? randomInt(count)
        const task = typeof indexOrText === "number" 
            ? this.ctx.page.locator(this.selectors.taskItems).nth(indexOrText)
            : this.ctx.page.locator(this.selectors.taskList).getByText(indexOrText, {exact: true}).first()
        return task
    }

    async toggleTask(indexOrText: number | string | undefined = undefined) {
        const task = await this.getTask(indexOrText)
        await task.locator(this.selectors.toggleButton).click()
    }

    async removeTask(indexOrText: number | string | undefined = undefined) {
        const task = await this.getTask(indexOrText)
        await task.locator(this.selectors.removeButton).click()
    }

    async editTask(description: string, indexOrText: number | string | undefined = undefined) {
        const task = await this.getTask(indexOrText)
        console.log(task, await task.textContent(), description)
        await task.click({clickCount: 2})
        // await task.locator(this.selectors.taskText).click({clickCount: 2})
        await this.ctx.page.locator("input.edit").fill(description)
        await this.ctx.page.locator("input.edit").press("Enter")
    }

    async clearCompletedTasks() {
        const clearButton = this.ctx.page.locator(this.selectors.clearCompletedButton);
        await clearButton.click();
    }

    async goto() {
        await this.ctx.page.goto("http://localhost:8080/todo")
    }
}

export {ToDoPage}