import { Locator } from '@playwright/test';
import { test, expect } from '../../core/context';

test.beforeEach(async ({ ctx }) => {
  await ctx.dsl.pageObjects.todoPage.goto();
})

test.afterEach(async ({ ctx }) => {
  await ctx.page.close()
})

// await test.step("", async () => {

// })

test.describe("Task Creation, Edit and Removal", () => {
  test("Create a task", async ({ ctx }) => {
    let beforeCount: number
    let taskName: string
    await test.step("Getting current task count and generating random name", async () => {
      beforeCount = await ctx.dsl.pageObjects.todoPage.getTaskCount() as number
      taskName = `From automation ${ctx.helpers.uuid()}`
    })
    let newTask: Locator
    await test.step("Creating the task", async () => {
      await ctx.dsl.pageObjects.todoPage.createTask(taskName)
      newTask = await ctx.dsl.pageObjects.todoPage.getTask(taskName)
    })
    await test.step("Verifying that task was created and added to the list", async () => {
      await expect(newTask).toBeVisible()
      expect(await ctx.dsl.pageObjects.todoPage.getTaskCount()).toBeGreaterThan(beforeCount)
    })
  })

  test("Edit a random task", async ({ ctx }) => {
    let task: Locator
    let originalName: string
    await test.step("Picking random task", async () => {
      task = await ctx.dsl.pageObjects.todoPage.getTask()
      originalName = await task.textContent() ?? ""
    })
    let newName: string
    await test.step("Editing the task", async () => {
      newName = `${originalName} ${ctx.helpers.uuid()}`
      await ctx.dsl.pageObjects.todoPage.editTask(newName, originalName)
    })
    await test.step("Verifying the task was edited", async () => {
      await expect(await ctx.dsl.pageObjects.todoPage.getTask(originalName)).not.toBeVisible()
      await expect(await ctx.dsl.pageObjects.todoPage.getTask(newName)).toBeVisible()
    })



  })
  test("Remove a random task", async ({ ctx }) => {
    const task = await ctx.dsl.pageObjects.todoPage.getTask()
    const taskName = await task.textContent() ?? ""
    await ctx.dsl.pageObjects.todoPage.removeTask(taskName)
    await expect(await ctx.dsl.pageObjects.todoPage.getTask(taskName)).not.toBeVisible()
  })
  test("", async ({ ctx }) => {

  })
})

